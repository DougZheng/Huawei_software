def main():
    # to read standard input
    # process
    # to write standard output
    # sys.stdout.flush()
    pass


if __name__ == "__main__":
    main()
